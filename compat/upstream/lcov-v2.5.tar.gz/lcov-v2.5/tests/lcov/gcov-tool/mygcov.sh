#!/bin/bash

exec gcov "$@"
